package com.generics.com

interface List<T> {
    operator fun get(index : Int) : T
}