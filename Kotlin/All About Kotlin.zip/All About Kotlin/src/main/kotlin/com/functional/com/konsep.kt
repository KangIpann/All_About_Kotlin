package com.functional.com

//fun getUsername() : List<String>{
//    return list.map{
//        it.name
//    }
//}

//val list = getListUser()
//
//fun getUsername(): List<String>{
//    val name = mutableListOf<String>()
//    for (user in list){
//        name.add(user.name)
//    }
//    return name
//}