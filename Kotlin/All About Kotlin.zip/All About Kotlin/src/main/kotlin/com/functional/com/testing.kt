package com.functional.com

fun main(){
    val anu = 4
    println(anu.div(2))
}