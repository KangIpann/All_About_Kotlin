fun main(){
    val name = "Ivan"
    print("Hello my name is ")
    println(name)
    print(if (false)"Always true" else "Always false")
    
}
