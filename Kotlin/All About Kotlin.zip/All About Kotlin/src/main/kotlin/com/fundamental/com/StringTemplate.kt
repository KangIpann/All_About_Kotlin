package com.fundamental.com

fun main() {

    val name : String = "Kotlin"
    println("Saya lagi ngoding $name")

//    String template = $
//    Untuk menyisipkan variable di dalam text tanpa menambahkan konotasi +
}