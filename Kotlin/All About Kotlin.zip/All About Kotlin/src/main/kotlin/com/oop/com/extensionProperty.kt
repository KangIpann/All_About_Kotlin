package com.oop.com

fun main(){
    val myPet = Animal("Julian", 66.2 , 99 , true )
    println(myPet.getAnimalInfo)
}