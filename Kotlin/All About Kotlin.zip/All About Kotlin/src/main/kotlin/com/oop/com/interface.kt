package com.oop.com

interface IFly{
    fun fly()
    val numberOfAngle: Int
}
